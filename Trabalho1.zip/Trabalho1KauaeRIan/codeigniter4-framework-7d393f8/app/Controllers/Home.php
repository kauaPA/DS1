<?php
namespace App\Controllers;
Use App\Models\UsuariosModel;
Use App\Models\LivrosModel;

class Home extends BaseController
{
    public function index(): string
    {
        return view('login');
    }

    public function telacadastro(): string
    {
        return view('cadastro');
    }

    public function recebercadastro(): string 
    {
        $data = array(
            'nome' => $this->request->getVar('nome'),
            'email' => $this->request->getVar('email'),
            'senha' => $this->request->getVar('senha')
        );

        $my_model= new UsuariosModel();
        $my_model->insert($data);
        $result= $my_model->findAll();
        $data['result']=$result;
       
        return view('cadastrado', $data);

    }

}